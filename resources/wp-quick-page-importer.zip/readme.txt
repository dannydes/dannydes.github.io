This plugin is perfect for scenarios where you lack FTP login details and have an urgent need to add a non-WordPress web application to your site.

After installing the plugin, go to "Settings" > "Quick Page Importer" and you will be expected to upload a zip file containing the page, containing every file and folder at the top-level of the archive. This is to be done by clicking "Upload file (.zip)" and then browsing to the zip file in the dialog that follows.

Once you select the file, click "Save Changes" and a new tab will be opened whereby you'll be informed of successful upload or some failure.