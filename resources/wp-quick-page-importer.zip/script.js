(function ( $ ) {
	$( '#file_link' ).click(function () {
		$( '#file' ).click();
	});
})( jQuery );